package com.duan.quanlychamthi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {
    private LinearLayout lnCamera, lnGV, lnPhieuCham, lnThongTin, lnMonHoc, lnThongKe;

   private Animation blink, l1, l2, l3, l12, l22, l32;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("TRANG CHỦ");
        //Tham chiếu id
        init();

        //Sự kiện khi click vào
        //Camera
        lnCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                lnCamera.startAnimation(blink);
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                Intent i = new Intent(MainActivity.this, CameraActivity.class);
                startActivity(i);
            }
        });

        //Giáo viên
        lnGV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, GiaoVienActivity.class);
                startActivity(i);
                lnGV.startAnimation(blink);
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            }
        });

        //Phiếu chấm bài
        lnPhieuCham.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, PhieuChamBaiActivity.class);
                startActivity(i);
                lnPhieuCham.startAnimation(blink);
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);

            }
        });

        //Thông tin chấm bài
        lnThongTin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, ThongTinChamBaiActivity.class);
                startActivity(i);
                lnThongTin.startAnimation(blink);
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);

            }
        });

        //Môn học
        lnMonHoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, MonHocActivity.class);
                startActivity(i);
                lnMonHoc.startAnimation(blink);
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);

            }
        });

        lnThongKe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ThongKeActivity.listTK.clear();
                Intent i = new Intent(MainActivity.this, ThongKeActivity.class);
                startActivity(i);
                lnThongKe.startAnimation(blink);
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            }
        });

    }

    private void init() {
        lnCamera = findViewById(R.id.lnCamera);
        lnGV = findViewById(R.id.lnGiaoVien);
        lnPhieuCham = findViewById(R.id.lnPhieuCham);
        lnThongTin = findViewById(R.id.lnThongTin);
        lnMonHoc = findViewById(R.id.lnMonHoc);
        lnThongKe = findViewById(R.id.lnThongKe);
        blink = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.faded);

        l1 = AnimationUtils.loadAnimation(this, R.anim.bot1);
        l2 = AnimationUtils.loadAnimation(this, R.anim.bot2);
        l3 = AnimationUtils.loadAnimation(this, R.anim.bot3);
        l12 = AnimationUtils.loadAnimation(this, R.anim.bot12);
        l22 = AnimationUtils.loadAnimation(this, R.anim.bot22);
        l32 = AnimationUtils.loadAnimation(this, R.anim.bot32);

        lnGV.setAnimation(l1);
        lnMonHoc.setAnimation(l12);
        lnPhieuCham.setAnimation(l2);
        lnThongTin.setAnimation(l22);
        lnCamera.setAnimation(l3);
        lnThongKe.setAnimation(l32);
    }

    @Override
    public void onBackPressed() {
        return;
    }
}